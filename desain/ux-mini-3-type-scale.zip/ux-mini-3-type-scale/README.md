# Kit desain: Type scale modular untuk artikel (Kabar Kampus)

Kit desain dari Ruang Kode. Semua file SVG bisa diimpor ke Figma dengan nama layer dan teks yang tetap bisa diedit.

## Isi folder
- `BRIEF.md` masalah, yang harus dihasilkan, dan kriteria penerimaan
- `hifi/` desain final siap slicing
- `wireframe-lofi/` wireframe untuk latihan menyusun struktur
- `variasi-gaya/` layar pertama dalam 3 gaya visual lain
- `prototype/index.html` prototype klik-through + demo mikro-interaksi
- `tokens.json` token DTCG 2025.10
- `aset/ikon/` ikon SVG yang dipakai
- `png/` pratinjau

## Langkah impor ke Figma
1. Ekstrak ZIP ini.
2. Pasang font gratis dari Google Fonts: Fraunces, Nunito, Outfit, Plus Jakarta Sans, Roboto Flex, Sora, Space Grotesk, Space Mono. Tanpa font ini Figma memakai font pengganti dan teks akan bergeser.
3. Buka file Figma baru, lalu seret (drag) file `.svg` ke kanvas. Bisa juga lewat menu **File > Place image** atau `Ctrl/Cmd + Shift + K`.
4. Setiap SVG masuk sebagai satu grup. Klik kanan grup itu, pilih **Frame selection** (`Ctrl/Cmd + Alt + G`), lalu beri nama frame sesuai nama file.
5. Nama layer sudah rapi (misalnya `Tombol/Pesan sekarang`, `Input/Nomor HP`, `Ikon/cart`). Lepas grup yang perlu diedit dengan **Ungroup** (`Ctrl/Cmd + Shift + G`).
6. Latihan design system: pilih satu tombol, tekan **Create component** (`Ctrl/Cmd + Alt + K`). Gabungkan state-nya menjadi **Variant** (default, hover, tekan, fokus, nonaktif, memuat).
7. Ubah frame bertumpuk (kartu, daftar, navbar) menjadi **Auto layout** (`Shift + A`) supaya responsif. SVG tidak membawa auto layout, jadi ini bagian dari latihanmu.
8. Token: impor `tokens.json` (format DTCG 2025.10) lewat plugin **Tokens Studio** atau **Variables Import**, lalu hubungkan warna ke Variables.
9. Prototype: buka `prototype/index.html` di browser untuk melihat alur dan animasinya. Tiru di Figma lewat tab **Prototype**: tarik sambungan dari tombol ke frame tujuan, pilih **Smart Animate** dengan durasi dan easing yang sama.
10. Slicing: pakai **Dev Mode** untuk melihat ukuran, warna, dan tipografi. Ekspor ikon dari folder `aset/ikon` (SVG) atau dari layer `Ikon/*`.

## Standar yang dipakai (2026-2030)
- WCAG 2.2 AA: kontras teks >= 4,5:1, target sentuh 48x48 (minimal 24x24), fokus terlihat dan tidak tertutup.
- Token format DTCG 2025.10 (primitif > semantik), siap multi-tema.
- Grid 4/8 pt, tipografi rasio 1,2, motion 100-400 ms dengan dukungan `prefers-reduced-motion`.
- Pola lokal Indonesia: QRIS, OTP/passkey, format Rp dan tanggal DD/MM/YYYY, persetujuan data terpisah (UU PDP).

Lisensi: bebas dipakai untuk belajar dan portofolio. Sebutkan "kit desain Ruang Kode" bila dipublikasikan.
