# Brief: Design system multi-brand

**Brand:** Nusa Group · **Platform:** Papan desain · **Gaya visual:** Modern minimal · **Skala:** proyek besar

Satu set komponen, tiga brand. Papan fondasi dan komponen untuk tiap brand dari token yang sama strukturnya (DTCG multi-brand).

## Yang harus kamu hasilkan
- Slicing / implementasi yang sama dengan desain hi-fi (selisih maksimal 2px di breakpoint utama).
- Semua state: default, hover, fokus, tekan, nonaktif, memuat, kosong, error.
- Responsif: 360, 768, 1024, 1440 (web) atau 360-430 lebar HP.
- Aksesibilitas WCAG 2.2 AA (cek dengan axe + keyboard).
- Animasi sesuai `prototype/index.html` dan tetap nyaman dengan `prefers-reduced-motion`.

## Kriteria penerimaan
1. Warna, radius, dan tipografi diambil dari `tokens.json`, bukan nilai lepas.
2. Lighthouse Performance dan Accessibility >= 90 di HP.
3. Tidak ada teks di dalam gambar; ikon punya label aksesibel.
4. Tulis studi kasus singkat untuk portofolio: masalah, keputusan desain, hasil.

## Variasi gaya
Folder `variasi-gaya/` berisi layar pertama dalam gaya lain. Struktur sama, hanya token yang berubah. Coba ganti token di kode slicing-mu untuk membuktikan tema bisa diganti tanpa mengubah komponen.
