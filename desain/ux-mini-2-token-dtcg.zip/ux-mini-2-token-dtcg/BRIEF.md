# Brief: Design token DTCG ke CSS

**Brand:** Lumbung · **Platform:** Papan desain · **Gaya visual:** Modern minimal · **Skala:** proyek mini

Papan fondasi dan tokens.json format DTCG 2025.10. Tugasmu: tulis generator yang mengubah tokens.json menjadi CSS custom properties terang dan gelap.

## Yang harus kamu hasilkan
- Slicing / implementasi yang sama dengan desain hi-fi (selisih maksimal 2px di breakpoint utama).
- Semua state: default, hover, fokus, tekan, nonaktif, memuat, kosong, error.
- Responsif: 360, 768, 1024, 1440 (web) atau 360-430 lebar HP.
- Aksesibilitas WCAG 2.2 AA (cek dengan axe + keyboard).
- Animasi sesuai `prototype/index.html` dan tetap nyaman dengan `prefers-reduced-motion`.

## Kriteria penerimaan
1. Warna, radius, dan tipografi diambil dari `tokens.json`, bukan nilai lepas.
2. Lighthouse Performance dan Accessibility >= 90 di HP.
3. Tidak ada teks di dalam gambar; ikon punya label aksesibel.
4. Tulis studi kasus singkat untuk portofolio: masalah, keputusan desain, hasil.

## Variasi gaya
Folder `variasi-gaya/` berisi layar pertama dalam gaya lain. Struktur sama, hanya token yang berubah. Coba ganti token di kode slicing-mu untuk membuktikan tema bisa diganti tanpa mengubah komponen.
